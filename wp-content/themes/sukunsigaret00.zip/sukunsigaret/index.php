<?php get_header(); ?>
<?php 
if(is_home()) {
	get_template_part('main');
}
?>

<?php get_footer(); ?>