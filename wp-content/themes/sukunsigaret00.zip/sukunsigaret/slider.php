	<?php if(is_home() || is_page('homepage')) { ?>

	<!-- Start Slider -->
	<div class="slider-container">	
	  	<div class="white">	
	  	<div class="">
	  		<div class="col-md-12">
	  			<?php echo do_shortcode('[masterslider id="1"]'); ?>
	  		</div>
	  	</div>   
      </div>
    </div>	
	<!-- End Slider -->
	<?php } ?>