<?php get_header(); ?>

    <div class="maincontent page">
      <div class="container">
	      <div class="row">
	      	<div class="col-md-7 wow fadeIn">
					
	      		<h1>Error Page</h1>
				<br /><br />
				<h1>404</h1>
				<h3>Sorry the page you requested may have been moved or deleted</h3>
		
			</div>
			<?php //get_sidebar(); ?>
		  </div>
	  </div>
    </div>

<?php get_footer(); ?>