	      	<div class="col-md-3 wow fadeIn">				
				<?php if ( is_active_sidebar( 'sidebar' ) ) { ?>
					<?php dynamic_sidebar( 'sidebar' ); ?>
				<?php } ?>
				
	      	</div>